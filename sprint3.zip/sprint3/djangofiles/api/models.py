from django.db import models

# Create your models here.
class Category(models.Model):
    objects = models.Manager()
    title = models.TextField()

class Product(models.Model):
    objects = models.Manager()
    name = models.TextField()
    category = models.ForeignKey(Category, on_delete=models.PROTECT)
    description = models.TextField()
    filename = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    
