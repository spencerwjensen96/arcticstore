import React from 'react'
import {Navbar, Nav, NavDropdown
    } from 'react-bootstrap'

class Top extends React.Component{
    render(){
      return(
        <div>
          <Navbar bg="info" expand="lg" className="border">
            <Navbar.Brand href="/"><i className="fab fa-artstation"></i>  Arctic General Store</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
              <Nav className="mr-auto">
                <Nav.Link href="/">Home</Nav.Link>
                <Nav.Link href="/about">About</Nav.Link>
                <Nav.Link href="/help">Help</Nav.Link>
              </Nav>
              <Nav>
                <NavDropdown title="Welcome, Friend" id="collasible-nav-dropdown" alignRight>
                    <NavDropdown.Item>Login</NavDropdown.Item>
                    <NavDropdown.Item>Sign Up</NavDropdown.Item>
                </NavDropdown>
              </Nav>
            </Navbar.Collapse>
          </Navbar>
        </div>
      )
    }
  }

  export default Top;