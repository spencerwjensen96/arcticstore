import React from 'react'

class Right extends React.Component{
    render(){
      return(
        <div>
          <br/>
          <h6>Recent</h6>
        </div>
      )
    }
  }

export default Right;