import React from 'react'
import {Button,
    Container, Col, Row, 
    Card} from 'react-bootstrap'

class AboutHeader extends React.Component{
    render(){
      return(
        <header className="App-header"  style={{backgroundColor: "light grey"}}>
          <div>
            <i className="far fa-newspaper m-3 p-4" style={{
              fontSize: "10rem",
              color: "#FAF9F9"
            }}></i></div>
          <div>
            <h1>About Northwest Labs</h1>
            
            <h3>Learn all about the best chemical testing company in the world!</h3>
          </div>
        </header>
      )
    }
  }

  class AboutContent extends React.Component{
    render(){
      return(
        <div>
          <AboutHeader/>
          <Container>
            <Row>
              <Col>
                <h1>About Page</h1>
                <p>This is some other content that we can put on here</p>
              </Col>
            </Row>
            <Row>
              <Col>
                <Card>
                  <Card.Img variant="top" src="" />
                  <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and make up the bulk of
                      the card's content.
                    </Card.Text>
                    <Button variant="info">Go somewhere</Button>
                  </Card.Body>
                </Card>
              </Col>
              <Col>
                <Card>
                  <Card.Img variant="top" src="" />
                  <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and make up the bulk of
                      the card's content.
                    </Card.Text>
                    <Button variant="info">Go somewhere</Button>
                  </Card.Body>
                </Card>
              </Col>
              <Col>
                <Card>
                  <Card.Img variant="top" src="" />
                  <Card.Body>
                    <Card.Title>Card Title</Card.Title>
                    <Card.Text>
                      Some quick example text to build on the card title and make up the bulk of
                      the card's content.
                    </Card.Text>
                    <Button variant="info">Go somewhere</Button>
                  </Card.Body>
                </Card>
             </Col>
            </Row>
            <Row>
              <br></br>
            </Row>
          </Container>
        </div>
      )
    }
  }

export default AboutContent;