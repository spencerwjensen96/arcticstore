import React from 'react'
import {Button,
    Container, Col, Row, 
    Card} from 'react-bootstrap'

    class HelpHeader extends React.Component{
        render(){
          return(
            <div>
              <header className="App-header"  style={{backgroundColor: "light grey"}}>
                <div>
                  <i className="fas fa-book-open m-3 p-4" style={{
                    fontSize: "10rem",
                    color: "#FAF9F9"
                  }}></i></div>
                <div>
                  <h1>Northwest Labs Help</h1>
                  
                  <h3>Where all your questions and life ambitions get answers!</h3>
                </div>
              </header>
            </div>
          )
        }
      }
      
      class HelpContent extends React.Component{
        render(){
          return (
            <div>
              <HelpHeader/>
              <Container>
                <Row>
                  <Col>
                    <h1>Help Page</h1>
                    <p>This is some other content that we can put on here</p>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Card>
                      <Card.Img variant="top" src="" />
                      <Card.Body>
                        <Card.Title>Card Title</Card.Title>
                        <Card.Text>
                          Some quick example text to build on the card title and make up the bulk of
                          the card's content.
                        </Card.Text>
                        <Button variant="info">Go somewhere</Button>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col>
                    <Card>
                      <Card.Img variant="top" src="" />
                      <Card.Body>
                        <Card.Title>Card Title</Card.Title>
                        <Card.Text>
                          Some quick example text to build on the card title and make up the bulk of
                          the card's content.
                        </Card.Text>
                        <Button variant="info">Go somewhere</Button>
                      </Card.Body>
                    </Card>
                  </Col>
                  <Col>
                    <Card>
                      <Card.Img variant="top" src="" />
                      <Card.Body>
                        <Card.Title>Card Title</Card.Title>
                        <Card.Text>
                          Some quick example text to build on the card title and make up the bulk of
                          the card's content.
                        </Card.Text>
                        <Button variant="info">Go somewhere</Button>
                      </Card.Body>
                    </Card>
                 </Col>
                </Row>
                <Row>
                  <br></br>
                </Row>
              </Container>
            </div>
          )
        }
      }

export default HelpContent;