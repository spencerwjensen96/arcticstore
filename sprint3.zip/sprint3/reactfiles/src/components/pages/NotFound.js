import React from 'react'
      
      class NotFound extends React.Component{
        render(){
          return (
            <div>
                    <h1>Page Not Found</h1>
                    <br/>
                    <br/>
                    <p>Sorry about that</p>
            </div>
          )
        }
      }

export default NotFound;